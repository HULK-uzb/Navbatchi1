package uz.navbatchi

import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object Commands {

    private val units = mapOf(
        "bir" to 1, "ikki" to 2, "uch" to 3, "to'rt" to 4, "besh" to 5,
        "olti" to 6, "yetti" to 7, "sakkiz" to 8, "to'qqiz" to 9
    )
    private val tens = mapOf(
        "o'n" to 10, "yigirma" to 20, "o'ttiz" to 30, "qirq" to 40, "ellik" to 50
    )
    private val monthNames = mapOf(
        "yanvar" to 0, "fevral" to 1, "mart" to 2, "aprel" to 3, "may" to 4, "iyun" to 5,
        "iyul" to 6, "avgust" to 7, "sentabr" to 8, "sentyabr" to 8,
        "oktabr" to 9, "oktyabr" to 9, "noyabr" to 10, "dekabr" to 11
    )
    private val aliases = mapOf(
        "ютуб" to "youtube", "yutub" to "youtube",
        "телеграм" to "telegram", "инстаграм" to "instagram",
        "ватсап" to "whatsapp", "vatsap" to "whatsapp", "watsap" to "whatsapp",
        "xrom" to "chrome"
    )
    private val folderMap = listOf(
        Triple(listOf("yuklama", "yuklab", "download"), "primary:Download", "Yuklamalar"),
        Triple(listOf("rasm", "surat"), "primary:Pictures", "Rasmlar"),
        Triple(listOf("hujjat", "dokument", "document"), "primary:Documents", "Hujjatlar"),
        Triple(listOf("musiqa", "musika", "music"), "primary:Music", "Musiqa"),
        Triple(listOf("video"), "primary:Movies", "Video"),
        Triple(listOf("kamera", "dcim"), "primary:DCIM", "Kamera")
    )

    private const val EXAMPLES =
        "Masalan: «ertaga soat 9 ga budilnik qo'y», «15 minutdan keyin eslat», " +
            "«10 minutdan keyin Instagramdan chiq», «bugungi rejani ayt»."

    private fun numberWords(s: String): String {
        val tk = s.split(" ").filter { it.isNotEmpty() }
        val out = ArrayList<String>()
        var i = 0
        while (i < tk.size) {
            val w = tk[i]
            val tn = tens[w]
            val un = units[w]
            if (tn != null) {
                val nx = if (i + 1 < tk.size) units[tk[i + 1]] else null
                if (nx != null) {
                    out.add((tn + nx).toString())
                    i += 2
                } else {
                    out.add(tn.toString())
                    i += 1
                }
            } else if (un != null) {
                out.add(un.toString())
                i += 1
            } else {
                out.add(w)
                i += 1
            }
        }
        return out.joinToString(" ")
    }

    private fun normalize(s: String): String {
        var t = s.lowercase(Locale.ROOT)
        for (ch in listOf('’', '‘', 'ʻ', 'ʼ', '`', '´')) t = t.replace(ch, '\'')
        t = t.replace("yarim soat", "30 minut")
        t = numberWords(t)
        for ((k, v) in aliases) t = t.replace(k, v)
        return t.replace(Regex("\\s+"), " ").trim()
    }

    private fun sameDay(a: Long, b: Long): Boolean {
        val x = Calendar.getInstance()
        x.timeInMillis = a
        val y = Calendar.getInstance()
        y.timeInMillis = b
        return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) &&
            x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)
    }

    private fun fmt(time: Long): String {
        val pattern = if (sameDay(time, System.currentTimeMillis())) "HH:mm" else "dd.MM HH:mm"
        return SimpleDateFormat(pattern, Locale.US).format(Date(time))
    }

    private fun cleanText(t: String): String {
        val stop = setOf(
            "navbatchi", "menga", "eslat", "eslatib", "eslatma", "eslatgin", "qo'y", "qo'yib",
            "qo'ying", "ber", "bering", "iltimos", "kerak", "deb", "bo'lganda", "bo'lsa",
            "soat", "keyin", "so'ng", "da", "ga", "ni", "ayt", "yoz"
        )
        return t.replace(Regex("[,.!?«»\"]"), " ")
            .split(" ")
            .filter { it.isNotBlank() && it !in stop && !it.startsWith("eslat") }
            .joinToString(" ")
    }

    private fun findApp(c: Context, t: String): Pair<String, String>? {
        val pm = c.packageManager
        val list = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
        var best: Pair<String, String>? = null
        var bestLen = 0
        for (ri in list) {
            val pkg = ri.activityInfo.packageName
            if (pkg == c.packageName) continue
            val label = ri.loadLabel(pm).toString()
            val l = label.lowercase(Locale.ROOT)
            var score = 0
            if (l.length >= 3 && t.contains(l)) {
                score = l.length
            } else {
                for (w in l.split(" ")) {
                    if (w.length >= 4 && t.contains(w) && w.length > score) score = w.length
                }
            }
            if (score > bestLen) {
                bestLen = score
                best = Pair(pkg, label)
            }
        }
        return best
    }

    private fun findFolder(t: String): Pair<String, String>? {
        for ((keys, id, name) in folderMap) {
            if (keys.any { t.contains(it) }) return Pair(id, name)
        }
        return null
    }

    private fun setAlarm(c: Context, time: Long, defaulted: Boolean): String {
        val note = if (defaulted) " (vaqt aytilmagani uchun 08:00 qo'ydim)" else ""
        if (time - System.currentTimeMillis() <= 24L * 3600_000L) {
            val cal = Calendar.getInstance()
            cal.timeInMillis = time
            val i = Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, cal.get(Calendar.HOUR_OF_DAY))
                .putExtra(AlarmClock.EXTRA_MINUTES, cal.get(Calendar.MINUTE))
                .putExtra(AlarmClock.EXTRA_MESSAGE, "Navbatchi")
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                c.startActivity(i)
                Store.add(c, time, "SYS_ALARM", "Budilnik")
                return "Budilnik qo'yildi: ${fmt(time)}.$note"
            } catch (e: Exception) {
            }
        }
        val task = Store.add(c, time, "ALARM", "Budilnik vaqti bo'ldi")
        Scheduler.schedule(c, task)
        return "Budilnik qo'yildi: ${fmt(time)}.$note"
    }

    private fun plan(c: Context, anyTime: Long): String {
        val items = Store.forDay(c, anyTime)
        val title = if (sameDay(anyTime, System.currentTimeMillis())) {
            "Bugungi reja"
        } else {
            SimpleDateFormat("dd.MM", Locale.US).format(Date(anyTime)) + " kungi reja"
        }
        if (items.isEmpty()) return "$title bo'sh. Hech narsa rejalashtirilmagan."
        val f = SimpleDateFormat("HH:mm", Locale.US)
        return title + ":\n" + items.joinToString("\n") { "${f.format(Date(it.time))} — ${it.text}" }
    }

    fun handle(c: Context, raw: String): String {
        var t = normalize(raw)
        val nowMs = System.currentTimeMillis()

        // 1. Nisbiy vaqt: "10 minutdan keyin"
        var offsetMs = -1L
        var relText = ""
        val rm = Regex(
            "(\\d+)\\s*(sekund|soniya|minut|daqiqa|min|soat)\\w*\\s*(?:dan\\s*)?(?:keyin|so'ng|song|o'tgach|o'tib)"
        ).find(t)
        if (rm != null) {
            val n = rm.groupValues[1].toLong()
            val unit = rm.groupValues[2]
            val mult: Long
            val unitName: String
            if (unit == "sekund" || unit == "soniya") {
                mult = 1000L
                unitName = "sekund"
            } else if (unit == "soat") {
                mult = 3600_000L
                unitName = "soat"
            } else {
                mult = 60_000L
                unitName = "minut"
            }
            offsetMs = n * mult
            relText = "$n $unitName"
            t = t.replaceRange(rm.range, " ")
        }

        // 2. Sana: "3 oktyabr"
        var day = -1
        var month = -1
        val dm = Regex(
            "(\\d{1,2})\\s*-?\\s*(yanvar|fevral|mart|aprel|may|iyun|iyul|avgust|sentabr|sentyabr|oktabr|oktyabr|noyabr|dekabr)\\w*"
        ).find(t)
        if (dm != null) {
            day = dm.groupValues[1].toInt()
            month = monthNames[dm.groupValues[2]] ?: -1
            t = t.replaceRange(dm.range, " ")
        }

        var dayShift = 0
        if (day < 0) {
            if (t.contains("ertadan keyin") || t.contains("indin")) {
                dayShift = 2
                t = t.replace("ertadan keyin", " ").replace(Regex("indin\\w*"), " ")
            } else if (Regex("ertaga|ertangi").containsMatchIn(t)) {
                dayShift = 1
                t = t.replace(Regex("ertaga\\w*|ertangi"), " ")
            } else if (t.contains("bugun")) {
                t = t.replace(Regex("bugun\\w*"), " ")
            }
        }

        // 3. Soat: "soat 9", "7:30", "9 ga"
        var hour = -1
        var minute = 0
        if (offsetMs < 0) {
            val tm = Regex("soat\\s*(\\d{1,2})(?:\\s*[:.]\\s*(\\d{2}))?").find(t)
                ?: Regex("\\b(\\d{1,2})\\s*[:.]\\s*(\\d{2})\\b").find(t)
                ?: Regex("\\b(\\d{1,2})\\s*(?:da|ga|dan|dagi)\\b").find(t)
            if (tm != null) {
                val h = tm.groupValues[1].toInt()
                val mi = tm.groupValues.getOrNull(2)?.toIntOrNull() ?: 0
                if (h in 0..23 && mi in 0..59) {
                    hour = h
                    minute = mi
                }
                t = t.replaceRange(tm.range, " ")
            }
            if (hour in 1..11 &&
                Regex("kechqurun|kechki|kechasi|tushdan keyin").containsMatchIn(t)
            ) {
                hour += 12
            }
            t = t.replace(Regex("kechqurun|kechki|kechasi|tushdan keyin|ertalab|tongda"), " ")
        }

        // 4. Aniq vaqtni hisoblash
        var target: Calendar? = null
        var defaulted = false
        if (offsetMs >= 0) {
            val cal = Calendar.getInstance()
            cal.timeInMillis = nowMs + offsetMs
            target = cal
        } else if (day > 0 && month >= 0) {
            if (hour < 0) {
                hour = 8
                minute = 0
                defaulted = true
            }
            val cal = Calendar.getInstance()
            cal.set(cal.get(Calendar.YEAR), month, day, hour, minute, 0)
            cal.set(Calendar.MILLISECOND, 0)
            if (cal.timeInMillis <= nowMs) cal.add(Calendar.YEAR, 1)
            target = cal
        } else if (hour >= 0 || dayShift > 0) {
            if (hour < 0) {
                hour = 8
                minute = 0
                defaulted = true
            }
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, dayShift)
            cal.set(Calendar.HOUR_OF_DAY, hour)
            cal.set(Calendar.MINUTE, minute)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            if (dayShift == 0 && cal.timeInMillis <= nowMs) cal.add(Calendar.DAY_OF_YEAR, 1)
            target = cal
        }

        // 5. Niyat
        val hasAlarm = t.contains("budil") || t.contains("uyg'ot")
        val hasRemind = t.contains("eslat")
        val hasPlan = t.contains("reja") || t.contains("ro'yxat")
        val hasLeave = t.contains("chiq")
        val hasOpen = Regex("\\boch\\w*|\\bkir\\w*|\\bo'ting\\w*").containsMatchIn(t)

        if (hasAlarm) {
            val tg = target ?: return "Budilnikni qaysi vaqtga qo'yay? $EXAMPLES"
            return setAlarm(c, tg.timeInMillis, defaulted)
        }

        if (hasRemind) {
            val tg = target ?: return "Qachon eslatay? $EXAMPLES"
            val txt = cleanText(t)
            val label = if (txt.isEmpty()) {
                "Eslatma vaqti bo'ldi"
            } else {
                txt.replaceFirstChar { it.uppercase() }
            }
            val task = Store.add(c, tg.timeInMillis, "REMIND", label)
            Scheduler.schedule(c, task)
            val when0 = if (relText.isNotEmpty()) "$relText dan keyin (${fmt(tg.timeInMillis)})" else fmt(tg.timeInMillis)
            return "Xo'p, $when0 eslataman." + if (txt.isNotEmpty()) " «$label»" else ""
        }

        if (hasPlan) {
            return plan(c, target?.timeInMillis ?: nowMs)
        }

        if (hasLeave) {
            val app = findApp(c, t)
            val pkg = app?.first ?: ""
            val name = app?.second ?: ""
            if (target == null) {
                val ok = Actions.leave(c, pkg)
                return if (ok) "Chiqdim." else if (NavbatchiService.instance == null) {
                    "Avval «Ilovadan chiqarish ruxsati»ni yoqing."
                } else {
                    "Hozir ${if (name.isNotEmpty()) "$name ochiq emas" else "chiqadigan ilova yo'q"}."
                }
            }
            val label = if (name.isNotEmpty()) "$name dan chiqiladi" else "Ilovadan chiqiladi"
            val task = Store.add(c, target.timeInMillis, "LEAVE_APP", label, pkg)
            Scheduler.schedule(c, task)
            val warn = if (NavbatchiService.instance == null) {
                " Diqqat: «Ilovadan chiqarish ruxsati» yoqilmagan, shuning uchun ishlamaydi."
            } else {
                ""
            }
            return "Xo'p, ${fmt(target.timeInMillis)} da ${if (name.isNotEmpty()) "$name ilovasidan " else ""}chiqaraman.$warn"
        }

        if (hasOpen) {
            val isFolder = t.contains("papka") || t.contains("folder")
            if (isFolder) {
                val f = findFolder(t)
                    ?: return "Qaysi papka? Hozircha: yuklamalar, rasmlar, hujjatlar, musiqa, video, kamera."
                if (target == null) {
                    Actions.openFolder(c, f.first, f.second)
                    return "${f.second} papkasini ochdim."
                }
                val task = Store.add(c, target.timeInMillis, "OPEN_FOLDER", "${f.second} papkasi ochiladi", "", f.first)
                Scheduler.schedule(c, task)
                return "Xo'p, ${fmt(target.timeInMillis)} da ${f.second} papkasini ochaman."
            }
            val app = findApp(c, t)
                ?: return "Qaysi ilovani ochay? Nomini ayting, masalan: «Telegramni och»."
            if (target == null) {
                Actions.openApp(c, app.first, app.second)
                return "${app.second} ochildi."
            }
            val task = Store.add(c, target.timeInMillis, "OPEN_APP", "${app.second} ochiladi", app.first)
            Scheduler.schedule(c, task)
            return "Xo'p, ${fmt(target.timeInMillis)} da ${app.second} ilovasini ochaman."
        }

        return "Tushunmadim. $EXAMPLES"
    }
}
