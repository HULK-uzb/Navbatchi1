package uz.navbatchi

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager

object Notif {
    private const val CH_REMIND = "remind"
    private const val CH_ALARM = "alarm"

    fun ensureChannels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        val r = NotificationChannel(CH_REMIND, "Eslatmalar", NotificationManager.IMPORTANCE_HIGH)
        val a = NotificationChannel(CH_ALARM, "Budilnik", NotificationManager.IMPORTANCE_HIGH)
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        a.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), attrs)
        a.enableVibration(true)
        a.vibrationPattern = longArrayOf(0, 500, 300, 500)
        nm.createNotificationChannel(r)
        nm.createNotificationChannel(a)
    }

    fun show(c: Context, title: String, text: String, loud: Boolean, pi: PendingIntent? = null) {
        ensureChannels(c)
        val open = pi ?: PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(c, if (loud) CH_ALARM else CH_REMIND)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        if (loud) n.flags = n.flags or Notification.FLAG_INSISTENT
        try {
            val id = (System.currentTimeMillis() % 1_000_000L).toInt()
            c.getSystemService(NotificationManager::class.java).notify(id, n)
        } catch (e: SecurityException) {
        }
    }
}
