package uz.navbatchi

import android.accessibilityservice.AccessibilityService
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.provider.DocumentsContract

object Actions {

    fun run(c: Context, t: Store.Task) {
        when (t.type) {
            "REMIND" -> Notif.show(c, "🔔 Eslatma", t.text, false)
            "ALARM" -> Notif.show(c, "⏰ Budilnik", t.text, true)
            "OPEN_APP" -> openApp(c, t.pkg, t.text)
            "OPEN_FOLDER" -> openFolder(c, t.folder, t.text)
            "LEAVE_APP" -> {
                if (!leave(c, t.pkg) && NavbatchiService.instance == null) {
                    Notif.show(
                        c,
                        "Navbatchi",
                        "Ilovadan chiqa olmadim: Navbatchi'ga «Maxsus imkoniyatlar» ruxsatini bering.",
                        false
                    )
                }
            }
        }
    }

    fun openApp(c: Context, pkg: String, label: String): Boolean {
        val launch = c.packageManager.getLaunchIntentForPackage(pkg)
        if (launch == null) {
            Notif.show(c, "Navbatchi", "Ilova topilmadi: $label", false)
            return false
        }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(
            c, pkg.hashCode(), launch,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        try {
            c.startActivity(launch)
        } catch (e: Exception) {
        }
        Notif.show(c, "Navbatchi", "$label — ochish uchun bosing", false, pi)
        return true
    }

    fun openFolder(c: Context, docId: String, label: String): Boolean {
        val uri = DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", docId)
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, DocumentsContract.Document.MIME_TYPE_DIR)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(
            c, docId.hashCode(), i,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        var ok = true
        try {
            c.startActivity(i)
        } catch (e: Exception) {
            ok = false
        }
        Notif.show(c, "Navbatchi", "$label papkasi — ochish uchun bosing", false, pi)
        return ok
    }

    fun leave(c: Context, pkg: String): Boolean {
        val svc = NavbatchiService.instance ?: return false
        var active: String? = null
        try {
            active = svc.rootInActiveWindow?.packageName?.toString()
        } catch (e: Exception) {
        }
        if (active == null) active = NavbatchiService.currentPackage
        if (pkg.isEmpty() || active == pkg || NavbatchiService.currentPackage == pkg) {
            return svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
        }
        return false
    }
}
