package uz.navbatchi

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class TaskReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getLongExtra("id", -1L)
        val t = Store.get(c, id) ?: return
        Store.remove(c, id)
        Actions.run(c, t)
    }
}
