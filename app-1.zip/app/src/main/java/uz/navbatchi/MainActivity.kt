package uz.navbatchi

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private val reqSpeech = 101
    private val reqNotif = 102

    private lateinit var txtStatus: TextView
    private lateinit var txtTasks: TextView
    private lateinit var txtPerm: TextView
    private lateinit var etCommand: EditText

    private var tts: TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtStatus = findViewById(R.id.txtStatus)
        txtTasks = findViewById(R.id.txtTasks)
        txtPerm = findViewById(R.id.txtPerm)
        etCommand = findViewById(R.id.etCommand)

        Notif.ensureChannels(this)
        tts = TextToSpeech(this, this)

        findViewById<ImageButton>(R.id.btnMic).setOnClickListener { startListening() }
        findViewById<Button>(R.id.btnRun).setOnClickListener {
            val t = etCommand.text.toString().trim()
            if (t.isNotEmpty()) {
                etCommand.setText("")
                runCommand(t)
            }
        }
        findViewById<Button>(R.id.btnClear).setOnClickListener {
            Store.clearAll(this)
            refresh()
            Toast.makeText(this, "Rejalar o'chirildi (soat ilovasidagi budilniklar qoladi)", Toast.LENGTH_LONG).show()
        }
        findViewById<Button>(R.id.btnNotif).setOnClickListener { requestNotif() }
        findViewById<Button>(R.id.btnAccess).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.btnOverlay).setOnClickListener {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }

        refresh()
        requestNotif()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        val t = tts ?: return
        var r = t.setLanguage(Locale("uz", "UZ"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            r = t.setLanguage(Locale("tr", "TR"))
        }
        ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
    }

    private fun speak(text: String) {
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "navbatchi")
    }

    private fun startListening() {
        txtStatus.text = "Labbay!"
        speak("Labbay")
        Handler(Looper.getMainLooper()).postDelayed({ launchRecognizer() }, 900)
    }

    private fun launchRecognizer() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "uz-UZ")
        i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Buyruq ayting")
        try {
            startActivityForResult(i, reqSpeech)
        } catch (e: ActivityNotFoundException) {
            txtStatus.text = "Telefonda ovozni tanish xizmati topilmadi. Buyruqni yozib bering."
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqSpeech && resultCode == RESULT_OK) {
            val list = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val text = list?.firstOrNull()
            if (!text.isNullOrBlank()) runCommand(text)
        }
    }

    private fun runCommand(text: String) {
        val reply = try {
            Commands.handle(this, text)
        } catch (e: Exception) {
            "Xatolik: ${e.message}"
        }
        txtStatus.text = "«$text»\n\n$reply"
        speak(reply)
        refresh()
    }

    private fun requestNotif() {
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), reqNotif)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    private fun refresh() {
        txtTasks.text = Store.describe(this)
        val n = getSystemService(NotificationManager::class.java).areNotificationsEnabled()
        val a = NavbatchiService.instance != null
        val o = Settings.canDrawOverlays(this)
        fun mark(b: Boolean) = if (b) "✅" else "⬜"
        txtPerm.text = "${mark(n)} Bildirishnoma\n${mark(a)} Ilovadan chiqarish\n${mark(o)} Ilova/papka ochish"
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }
}
