package uz.navbatchi

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object Store {

    data class Task(
        val id: Long,
        val time: Long,
        val type: String,
        val text: String,
        val pkg: String,
        val folder: String
    )

    private fun prefs(c: Context) = c.getSharedPreferences("navbatchi", Context.MODE_PRIVATE)

    @Synchronized
    fun all(c: Context): MutableList<Task> {
        val list = mutableListOf<Task>()
        try {
            val arr = JSONArray(prefs(c).getString("tasks", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    Task(
                        o.getLong("id"),
                        o.getLong("time"),
                        o.getString("type"),
                        o.optString("text"),
                        o.optString("pkg"),
                        o.optString("folder")
                    )
                )
            }
        } catch (e: Exception) {
        }
        return list
    }

    private fun save(c: Context, list: List<Task>) {
        val arr = JSONArray()
        for (t in list) {
            arr.put(
                JSONObject()
                    .put("id", t.id)
                    .put("time", t.time)
                    .put("type", t.type)
                    .put("text", t.text)
                    .put("pkg", t.pkg)
                    .put("folder", t.folder)
            )
        }
        prefs(c).edit().putString("tasks", arr.toString()).apply()
    }

    @Synchronized
    fun add(
        c: Context,
        time: Long,
        type: String,
        text: String,
        pkg: String = "",
        folder: String = ""
    ): Task {
        val p = prefs(c)
        val id = p.getLong("next", 1L)
        p.edit().putLong("next", id + 1).apply()
        val list = all(c)
        val t = Task(id, time, type, text, pkg, folder)
        list.add(t)
        save(c, list)
        return t
    }

    @Synchronized
    fun get(c: Context, id: Long): Task? = all(c).firstOrNull { it.id == id }

    @Synchronized
    fun remove(c: Context, id: Long) {
        save(c, all(c).filter { it.id != id })
    }

    @Synchronized
    fun clearAll(c: Context) {
        for (t in all(c)) Scheduler.cancel(c, t.id)
        save(c, emptyList())
    }

    @Synchronized
    fun upcoming(c: Context): List<Task> {
        val now = System.currentTimeMillis()
        val list = all(c)
        val keep = list.filter { !(it.type == "SYS_ALARM" && it.time < now) }
        if (keep.size != list.size) save(c, keep)
        return keep.sortedBy { it.time }
    }

    fun forDay(c: Context, anyTime: Long): List<Task> {
        val cal = Calendar.getInstance()
        cal.timeInMillis = anyTime
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val start = cal.timeInMillis
        val end = start + 24L * 3600_000L
        return upcoming(c).filter { it.time >= start && it.time < end }
    }

    fun icon(type: String): String = when (type) {
        "SYS_ALARM", "ALARM" -> "⏰"
        "REMIND" -> "🔔"
        "OPEN_APP" -> "▶️"
        "LEAVE_APP" -> "⏹"
        "OPEN_FOLDER" -> "📁"
        else -> "•"
    }

    fun describe(c: Context): String {
        val l = upcoming(c)
        if (l.isEmpty()) return "Hozircha reja yo'q."
        val f = SimpleDateFormat("dd.MM  HH:mm", Locale.US)
        return l.joinToString("\n") { "${f.format(Date(it.time))}   ${icon(it.type)} ${it.text}" }
    }
}
