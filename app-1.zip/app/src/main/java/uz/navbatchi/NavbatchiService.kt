package uz.navbatchi

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class NavbatchiService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: NavbatchiService? = null

        @Volatile
        var currentPackage: String = ""
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val p = event.packageName?.toString() ?: return
        if (p == "com.android.systemui" || p.contains("inputmethod") || p.contains("keyboard")) return
        currentPackage = p
    }

    override fun onInterrupt() {}
}
