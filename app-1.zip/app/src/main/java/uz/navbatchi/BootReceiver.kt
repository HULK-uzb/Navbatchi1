package uz.navbatchi

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED) return
        val now = System.currentTimeMillis()
        for (t in Store.all(c)) {
            if (t.type != "SYS_ALARM" && t.time > now) Scheduler.schedule(c, t)
        }
    }
}
